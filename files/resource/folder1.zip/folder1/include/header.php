<div class="container">
			<div class="row">
				<div class="col-md-12">
					<nav class="navbar navbar-expand-lg navbar-light bg-primary">
					  <a class="navbar-brand" href="#">Training-2018</a>
					  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					    <span class="navbar-toggler-icon"></span>
					  </button>
					  <div class="collapse navbar-collapse" id="navbarSupportedContent">
					    <ul class="navbar-nav mr-auto">
					      <li class="nav-item active">
					        <a class="nav-link" href="index.php">Home</a>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="index.php">Registration</a>
					      </li>
					      <li class="nav-item dropdown">
					        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Courses</a>
					        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
					          <a class="dropdown-item" href="java-training.php">Java Training</a>
					          <a class="dropdown-item" href="#">Python Training</a>
					          <a class="dropdown-item" href="#">Cloud Computing</a>
					        </div>
					      </li>
					      <li class="nav-item">
					        <a class="nav-link" href="#">Blog</a>
					      </li>
					    </ul>
					    <form class="form-inline">
						    <div class="input-group">
						      <div class="input-group-prepend">
						        <span class="input-group-text" id="basic-addon1"><i class="fa fa-search" aria-hidden="true"></i></span>
						      </div>
						      <input type="text" class="form-control" placeholder="Search Here" aria-label="Username" aria-describedby="basic-addon1">
						    </div>
						  </form>
					  </div>
					</nav>
				</div>
			</div>
		</div>