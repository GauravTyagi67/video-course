<?php 
//$con=mysqli_connect("localhost","roorkee_training","training@2018", "roorkee_training") or die("Can not connect to database");
    require 'phpmailer/src/Exception.php';
    require 'phpmailer/src/PHPMailer.php';
    require 'phpmailer/src/SMTP.php';

    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $mob=$_POST['mobile'];
    $email=$_POST['email'];
    $adrs=$_POST['address'];
    $city=$_POST['city'];
    $edu=$_POST['edu'];
    $course=$_POST['course'];
    $to='rtyagi519@gmail.com';
    $from=$email;
    $subject='Workshop Notes';
    // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    // More headers
    $headers .= "FROM:no-reply@traininginroorkee.in \r\n";
    $headers .= 'Reply-To: '.$from.'';
    $starthtml="<html><head><style>h3{color: #bc6e00;font-size:20px;}.tbl{border:1px solid #ffb24f;border-radius:3px;box-shadow:0px 0px 10px #bc6e00;}.tbl .evn{background-color:#ffddb2;}.tbl .od{background-color:#dcffb2;}</style></head><body>";
    $endhtml="</body>";
    $msg=$starthtml."<img src='http://www.cetpainfotech.com/images/logosc.png' width='100' height='75' alt='Cetpa'><h3>Enqueiry Details:</h3><table width='500' cellpadding='2' cellspacing='2' class='tbl'><tr class='evn'><td>Name: </td><td>".$fname." ".$lname."</td></tr><tr class='od'><td>Contact: </td><td>".$mob."</td></tr><tr class='evn'><td>Email: </td><td>".$email."</td></tr><tr class='od'><td>Address: </td><td>".$adrs."</td></tr><tr class='evn'><td>City: </td><td>".$city."</td></tr><tr class='od'><td>Qualification: </td><td>".$edu."</td></tr><tr class='evn'><td>Course: </td><td>".$course."</td></tr></table>".$endhtml;
    if(mail($to,$subject,$msg,$headers))
    {
        echo "<script>alert('Thanks for registering with us!');window.location.href='index.php';</script>";
    }

?>

