<div class="container">
		<div class="row">			
			<div class="col-md-3 tab rbd">
				<img src="svg/si-glyph-android.svg" />Computer Science
			</div>
			<div class="col-md-3 tab rbd lbd">
				<img src="svg/si-glyph-gear-1.svg"/>Mechanical
			</div>
			<div class="col-md-3 tab rbd lbd">
				<img src="svg/si-glyph-city.svg"/>Civil
			</div>
			<div class="col-md-3 tab lbd">
				<img src="svg/si-glyph-cpu.svg" />Electronics/Electrical
			</div>			
		</div>		
	</div>