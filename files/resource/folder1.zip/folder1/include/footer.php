<div class="container">
		<div class="row">
			<div class="col-md-6 copy">
				Copyright &copy;2018. All rights reserved to <a href="http://techonical.com/">Training-2018</a> 
			</div>
			<div class="col-md-6 slink">
				<ul class="social-icons icon-circle icon-rotate list-unstyled list-inline"> 
			      <li> <a href="#"><i class="fa fa-facebook"></i></a> </li> 
			      <li> <a href="#"><i class="fa fa-youtube"></i></a></li> 
			      <li> <a href="#"><i class="fa fa-twitter"></i></a> </li> 
			      <li> <a href="#"><i class="fa fa-google-plus"></i></a></li> 
			      <li> <a href="#"><i class="fa fa-linkedin"></i></a></li>  	        
	  			</ul>
			</div>
		</div>
	</div>