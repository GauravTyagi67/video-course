<!DOCTYPE html>
<html>
<head>
	<?php include('include/script.php');?>
</head>
<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TPJHTXK"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
	<header>
		<?php include('include/header.php');?>
	</header>
<section class="contentbg">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1>Advanced Java</h1>
			</div>		
		</div>
	</div>
</section>
<section class="stream">
	<?php include('include/stream.php');?>
</section>
<section class="course">
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<h2>Advanced Java Training in Roorkee</h2>
				<img src="img/java-training.png" class="img-thumbnail pull-left">
				<p>
					   CETPA Infotech Pvt Ltd is the No 1 training Company in Roorkee for JAVA as well other latest technologies. CETPA provides real-time and placement oriented JAVA course in Roorkee. CETPA’s JAVA training course content is basically designed from basic to advanced levels. CETPA Roorkee is having best JAVA Training infrastructure in the region. CETPA Roorkee and other branches have team of the best JAVA Training experts who are working professionals with hands on real time JAVA projects expertise, which provides CETPA an edge over other JAVA training Institutes. CETPA Roorkee has basically designed the JAVA training course content for the students as well as professionals to get the placement in major MNC companies as soon as they complete the JAVA training course. JAVA training in Roorkee imparted by CETPA Infotech is delivered on short term as well as long term basis. CETPA also imparts JAVA training on Live Projects. CETPA Infotech is also an authorized training partner of Nuvotan- ARM Cortex, Microsoft, JAVA, Panasonic and Autodesk.	
				</p>
			</div>
			<div class="col-md-3">
				<div class="course-content">
					<h3><i class="fa fa-book" aria-hidden="true"></i> Course Content</h3>	<ul>
						<li>Introduction</li>
						<li>Looping & Control Structure</li>
					</ul>
				</div>
				
			</div>			
		</div>
	</div>
</section>
<section class="second-footer">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h4>Related Links</h4>
				<div class="row">
					<div class="col-md-3">
						<ul>
							<li><a href="#">Python Training</a></li>
							<li><a href="#">Data Science Training</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul>
							<li><a href="#">Machine Learning Training</a></li>
							<li><a href="#">Dot Net Training</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul>
							<li><a href="#">Advanced Php Training</a></li>
							<li><a href="#">H/W & N/W Training</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul>
							<li><a href="#">Cloud Computing Training</a></li>
							<li><a href="#">Ethical Hacking Training</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				
			</div>
		</div>
	</div>
</section>
<footer>
	<?php include('include/footer.php');?>
</footer>
</body>
</html>
