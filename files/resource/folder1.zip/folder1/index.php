<?php 
//$con=mysqli_connect("localhost","roorkee_training","training@2018", "roorkee_training") or die("Can not connect to database");
if(isset($_POST['submit']))
{
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $mob=$_POST['mobile'];
    $email=$_POST['email'];
    $adrs=$_POST['address'];
    $city=$_POST['city'];
    $edu=$_POST['edu'];
    $course=$_POST['course'];
    $to='rtyagi519@gmail.com';
    $from=$email;
    $subject='Workshop Notes';
    // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    // More headers
    $headers .= "FROM:no-reply@traininginroorkee.in \r\n";
    $headers .= 'Reply-To: '.$from.'';
    $starthtml="<html><head><style>h3{color: #bc6e00;font-size:20px;}.tbl{border:1px solid #ffb24f;border-radius:3px;box-shadow:0px 0px 10px #bc6e00;}.tbl .evn{background-color:#ffddb2;}.tbl .od{background-color:#dcffb2;}</style></head><body>";
    $endhtml="</body>";
    $msg=$starthtml."<img src='http://www.cetpainfotech.com/images/logosc.png' width='100' height='75' alt='Cetpa'><h3>Enqueiry Details:</h3><table width='500' cellpadding='2' cellspacing='2' class='tbl'><tr class='evn'><td>Name: </td><td>".$fname." ".$lname."</td></tr><tr class='od'><td>Contact: </td><td>".$mob."</td></tr><tr class='evn'><td>Email: </td><td>".$email."</td></tr><tr class='od'><td>Address: </td><td>".$adrs."</td></tr><tr class='evn'><td>City: </td><td>".$city."</td></tr><tr class='od'><td>Qualification: </td><td>".$edu."</td></tr><tr class='evn'><td>Course: </td><td>".$course."</td></tr></table>".$endhtml;
    if(mail($to,$subject,$msg,$headers))
    {
        echo "<script>alert('Thanks for registering with us!');window.location.href='index.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include('include/script.php');?>
</head>
<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TPJHTXK"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
	<header>
		<?php include('include/header.php');?>
	</header>
<section class="contentbg">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="row">
					<div class="col-md-6">
						<div class="tiles redtile">
							<img src="svg/si-glyph-android-1.svg" alt="cs" />
							<p><a href="#">Computer Science</a></p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="tiles greentile">
							<img src="svg/si-glyph-gear.svg" alt="me" />
							<p><a href="#">Mechanical Eng.</a></p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="tiles yellowtile">
							<img src="svg/si-glyph-city-1.svg" alt="ce" />
							<p><a href="">Civil Eng.</a></p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="tiles bluetile">
							<img src="svg/si-glyph-cpu-1.svg" alt="ec" />
							<p><a href="">EC & EE Eng.</a></p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="frm">
  					<div class="frm-header">
    					Registration Form
  					</div>
  					<div class="frm-body">
    					<form method="POST">
    					<div class="row">
    						<div class="col-md-6">
    							<div class="form-group">
								    <label for="firstname">First Name:</label>
								    <input type="text" class="form-control" id="fname" name="fname" aria-describedby="emailHelp" required="" placeholder="Enter Your First Name">
								 </div>
    						</div>
    						<div class="col-md-6">
    							<div class="form-group">
								    <label for="lastname">Last Name:</label>
								    <input type="text" class="form-control" id="lname" name="lname" aria-describedby="emailHelp" required="" placeholder="Enter Your First Name">
								 </div>
    						</div>
    					</div>
    					<div class="row">
    						<div class="col-md-6">
    							<div class="form-group">
								    <label for="mobile">Contact No:</label>
								    <input type="text" class="form-control" id="mobile" name="mobile" aria-describedby="emailHelp" required="" placeholder="Enter Your Contact No.">
							    </div>
    						</div>
    						<div class="col-md-6">
    							<div class="form-group">
								    <label for="email">Email Id:</label>
								    <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter Your Email">
							  </div>
    						</div>
    					</div>
    					<div class="row">
    						<div class="col-md-6">
    							<div class="form-group">
								    <label for="address">Address:</label>
								    <input type="text" class="form-control" id="address" name="address" aria-describedby="emailHelp" required="" placeholder="Enter Your Address">
							    </div>
    						</div>
    						<div class="col-md-6">
    							<div class="form-group">
								    <label for="state">City:</label>
								    <input type="text" class="form-control" id="city" name="city" aria-describedby="emailHelp" required="" placeholder="Enter Your City">
							  </div>
    						</div>
    					</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
								    <label for="password">Qualification:</label>
								    <input type="text" class="form-control" id="edu" name="edu" placeholder="Your Educational Qualification">
							   </div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
								    <label for="confirmpassword">Course to be Joined:</label>
								    <input type="text" class="form-control" id="cpassword" name="course" placeholder="Python, PHP, Java, Hacking etc..">
							   </div>
							</div>
						</div> 
						<button type="submit" name="submit" class="btn btn-primary">Register</button>
						</form>
  					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="stream">
	<?php include('include/stream.php');?>
</section>
<section class="technologies">
	<div class="container">
		<div class="row">
			<div class="col-md-3 baseline">
				<ul>
					<li><a href="#">Programming</a></li>
					<li><a href="#">Graphics Designing</a></li>
					<li><a href="#">Business Accounting</a></li>
					<li><a href="#">Digital Marketing</a></li>
					<li><a href="#">Computer Basics</a></li>
				</ul>
			</div>
			<div class="col-md-3 baseline">
				<ul>
					<li><a href="#">Autocad</a></li>
					<li><a href="#">Catia</a></li>
					<li><a href="#">Solid Works</a></li>
					<li><a href="#">Ansys</a></li>
					<li><a href="#">Pro-e (Creo)</a></li>
				</ul>
			</div>
			<div class="col-md-3 baseline">
				<ul>
					<li><a href="#">Autocad</a></li>
					<li><a href="#">Revit</a></li>
					<li><a href="#">Staad Pro</a></li>
					<li><a href="#">3D Max</a></li>
					<li><a href="#">Revit MEP</a></li>
				</ul>
			</div>
			<div class="col-md-3">
				<ul>
					<li><a href="#">IOT</a></li>
					<li><a href="#">Embedded System</a></li>
					<li><a href="#">PLC Scada</a></li>
					<li><a href="#">Matlab</a></li>
					<li><a href="#">PCB Designing</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<footer>
	<?php include('include/footer.php');?>
</footer>
</body>
</html>
